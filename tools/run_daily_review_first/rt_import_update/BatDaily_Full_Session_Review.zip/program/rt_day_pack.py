"""Lossless per-device, NZ upload-date logs with a readable first-occurrence view."""
import argparse
from collections import defaultdict
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import zipfile
from zoneinfo import ZoneInfo

from rt_logs import backup_timestamp


def sha(data):
    return hashlib.sha256(data).hexdigest()


def restore(lines, row):
    crlf = set(row.get("crlf", []))
    last = len(row["lines"]) - 1
    data = b"".join(lines[n - 1] + (b"" if i == last and row.get("unterminated")
                                    else b"\r\n" if i in crlf else b"\n")
                    for i, n in enumerate(row["lines"]))
    if len(data) != row["bytes"] or sha(data) != row["sha256"]:
        raise ValueError("Upload reconstruction failed: " + row["file"])
    return data


def read_pack(path):
    with zipfile.ZipFile(path) as bundle:
        lines = bundle.read("daily.log").split(b"\n")[:-1]
        rows = [json.loads(s) for s in bundle.read("uploads.jsonl").splitlines()]
    return {row["file"]: restore(lines, row) for row in rows}


def build(path, sources, device, day):
    # Receiver retention can remove an old source after the first publication.
    stored = read_pack(path) if path.is_file() else {}
    payloads = dict(stored)
    for src in sources:
        data = src.read_bytes()
        if src.name in stored and stored[src.name] != data:
            raise ValueError(f"Receiver bytes conflict with the saved daily pack: {src}")
        payloads[src.name] = data
    if payloads == stored:
        return
    numbers, rows = {}, []
    for name, data in sorted(payloads.items()):
        row = {"file": name, "bytes": len(data), "sha256": sha(data), "lines": []}
        for i, raw in enumerate(io.BytesIO(data)):
            if raw.endswith(b"\r\n"):
                line = raw[:-2]
                row.setdefault("crlf", []).append(i)
            elif raw.endswith(b"\n"):
                line = raw[:-1]
            else:
                line = raw
                row["unterminated"] = True
            row["lines"].append(numbers.setdefault(line, len(numbers) + 1))
        rows.append(row)
    summary = dict(device=device, nz_receiver_date=day, files=len(rows),
                   input_bytes=sum(r["bytes"] for r in rows),
                   line_occurrences=sum(len(r["lines"]) for r in rows),
                   distinct_lines=len(numbers), format_version=1)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name, suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
            bundle.writestr("daily.log", b"".join(line + b"\n" for line in numbers))
            bundle.writestr("uploads.jsonl", "\n".join(json.dumps(r, separators=(",", ":")) for r in rows) + "\n")
            bundle.writestr("summary.json", json.dumps(summary, indent=2))
        if read_pack(tmp) != payloads:
            raise ValueError("Daily pack differs from source uploads: " + str(path))
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)
    print(f"XiaoRT {day} {device}: {len(rows)} uploads, {summary['line_occurrences']} lines, "
          f"{len(numbers)} distinct. Verified daily log: {path}", flush=True)


def pack_days(root, days, output=None):
    receiver = root / "WiFi_Backup" / "RT"
    if not receiver.is_dir():
        return
    groups = defaultdict(list)
    zone = ZoneInfo("Pacific/Auckland")
    for device in receiver.iterdir():
        if not device.is_dir() or device.resolve() != device:
            continue
        for item in device.glob("*.txt"):
            stamp = backup_timestamp(item)
            if stamp:
                day = stamp.astimezone(zone).strftime("%Y%m%d")
                if (days is None or day in days) and item.resolve() == item and item.is_file():
                    groups[device.name, day].append(item)
    output = output or root / "Daily_Run_Reports" / "RT_Daily_Logs"
    for (device, day), sources in sorted(groups.items()):
        build(output / device / (day + ".zip"), sources, device, day)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--day", action="append", help="NZ receiver date YYYYMMDD. Omit for all dates.")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    pack_days(args.root.resolve(), set(args.day) if args.day else None, args.output)
