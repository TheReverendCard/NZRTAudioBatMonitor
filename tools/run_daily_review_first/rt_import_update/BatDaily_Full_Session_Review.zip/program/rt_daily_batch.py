"""Batch the pending RT receiver text uploads from the review-first daily queue."""

import json
import time
from collections import Counter, defaultdict
from datetime import timedelta
from zoneinfo import ZoneInfo

import rt_logs


def import_pending(state, resolve_path, receiver_signature):
    root = state.root
    task = "rtlogs-file"
    pending = state.pending(task)
    groups = defaultdict(list)
    ignored = []
    zone = ZoneInfo("Pacific/Auckland")
    started = time.perf_counter()
    for rel in pending:
        path = resolve_path(root, rel)
        stamp = rt_logs.backup_timestamp(path)
        if stamp is None or path.suffix.lower() != ".txt" or not path.is_file():
            ignored.append(rel)
            continue
        groups[stamp.astimezone(zone).date()].append((rel, path))

    def checkpoint(rels):
        state.db.executemany("DELETE FROM jobs WHERE stage=? AND item=?",
                             ((task, rel) for rel in rels))
        state.db.commit()

    checkpoint(ignored)
    total = sum(map(len, groups.values()))
    if not total:
        print(f"XiaoRT: no timestamped text uploads in {len(pending)} queue entries.", flush=True)
        return
    print(f"XiaoRT: {total} uploads across {len(groups)} NZ dates. Reading archive receipts once.", flush=True)
    index_start = time.perf_counter()
    index = rt_logs.ReceiptIndex(root, state.db)
    indexed = time.perf_counter()
    print(f"XiaoRT: indexed {index.count} receipts ({index.cached} cached) in {indexed-index_start:.2f}s.", flush=True)
    counts = Counter()
    processed = 0
    last_progress = indexed
    for date, rows in sorted(groups.items()):
        day = date.strftime("%Y%m%d")
        paths = []
        errors = []
        day_counts = Counter()
        for rel, path in sorted(rows):
            signature = receiver_signature(path)
            if state.blocked(rel, signature):
                day_counts["quarantined"] += 1
            else:
                try:
                    with path.open("rb") as stream:
                        sample = stream.read(8192)
                        data = sample + stream.read() if b"NZRT " in sample else None
                except OSError as exc:
                    state.reject(rel, signature, exc)
                    day_counts["read_errors"] += 1
                    errors.append(f"{rel}: {exc}")
                else:
                    if receiver_signature(path) != signature:
                        raise RuntimeError(f"Receiver upload changed during import. Retry {rel}")
                    if data is None:
                        day_counts["non_nzrt"] += 1
                    else:
                        before = index.created
                        archive, meta = rt_logs.import_log_bytes(root, path, data, index)
                        day_counts["new" if index.created > before else "reused"] += 1
                        paths.append(archive.relative_to(root).as_posix())
                        day_counts["source_bytes"] += len(data)
            processed += 1
            now = time.perf_counter()
            if now - last_progress >= 10:
                print(f"XiaoRT: {processed}/{total} uploads checked in {now-started:.1f}s.", flush=True)
                last_progress = now
        receipt = root / "Daily_Run_Reports" / day / "XiaoRT" / "collection.json"
        prior = rt_logs.read_json(receipt, {})
        if paths:
            history = list(prior.get("archived_logs", []))
            if prior.get("raw_log"):
                history.append(prior["raw_log"])
            archives = list(dict.fromkeys(history + paths))
            rt_logs.collection_status(root, day, "wifi_imported", raw_log=paths[-1],
                                      sha256=meta["sha256"], complete=bool(meta["complete"]),
                                      files_imported=len(archives), archived_logs=archives,
                                      skipped_files=day_counts["non_nzrt"], errors=errors,
                                      batch=dict(day_counts))
            for offset in (-1, 0, 1):
                target = (date + timedelta(days=offset)).strftime("%Y%m%d")
                if (root / target).is_dir():
                    state.put("timeline-day", target)
                    state.put("final", "timelines")
        elif prior.get("status") not in {"wifi_imported", "imported", "downloaded"}:
            rt_logs.collection_status(root, day, "not_collected", searched_files=len(rows),
                                      skipped_files=day_counts["non_nzrt"], errors=errors,
                                      batch=dict(day_counts))
        state.put("rt-pack-day", day)
        # Publish the receipt and downstream work before clearing this date's jobs.
        checkpoint(rel for rel, _ in rows)
        counts.update(day_counts)
    elapsed = time.perf_counter() - started
    print(f"XiaoRT: {processed} checked, {counts['new']} newly archived, "
          f"{counts['reused']} verified duplicates, {counts['non_nzrt']} non-NZRT, "
          f"{counts['read_errors']} read errors, {counts['quarantined']} already quarantined, "
          f"{elapsed:.2f}s.", flush=True)
    detail = dict(counts)
    detail.update(checked=processed, other_queue_entries=len(ignored), receipts_indexed=index.count,
                  cached_receipts=index.cached, invalid_receipts=index.invalid,
                  index_seconds=round(indexed-index_start, 3),
                  total_seconds=round(elapsed, 3), run=state.run)
    state.db.execute("INSERT OR REPLACE INTO notes VALUES (?,?)",
                     ("rt-import-latest", json.dumps(detail, sort_keys=True)))
    state.db.commit()
