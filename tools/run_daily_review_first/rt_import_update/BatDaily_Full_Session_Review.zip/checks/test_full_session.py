import json
import os
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image
from daily_state import State
import fast_review_entrypoint
import review_first_daily as daily
from review_unreviewed_queue import ReviewQueue, REVIEWER, human_grade


class FullSessionTests(unittest.TestCase):
    def test_large_daily_session_and_resume(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            state = State(root)
            folder = root / "20261122" / "AR420261122"
            backup = folder / "Backup"
            backup.mkdir(parents=True)
            template = root / "test.bmp"
            Image.new("RGB", (10, 5)).save(template)
            bitmap = template.read_bytes()
            annotation = json.dumps([{"Duration": 1, "Operator": "Auto", "Reviewer": ""}])
            sources = []
            for i in range(626):
                bmp = folder / f"20261122_{i:06d}.bmp"
                bmp.write_bytes(bitmap)
                side = Path(str(bmp) + ".data")
                side.write_text(annotation)
                if i != 620:
                    (backup / side.name).write_text(annotation)
                rel = bmp.relative_to(root).as_posix()
                sources.append(rel)
                state.db.execute("INSERT INTO review VALUES (?)", (rel,))

            def grade(shadow):
                contents = json.loads(shadow.read_text())
                contents[0].update(Reviewer=REVIEWER, BatDailyReview={
                    "grade": 5, "reviewer": REVIEWER, "source": "avianz_gui_hotkey"})
                shadow.write_text(json.dumps(contents))

            grade(Path(str(root / sources[-1]) + ".data"))
            state.db.commit()
            catchup = ReviewQueue(root)
            catchup.sources = lambda: ((root / s, s) for s in sources)
            self.assertEqual(catchup.prepare()["queue_size"], 150)
            self.assertEqual(ReviewQueue(root, 500).limit, 500)
            with self.assertRaises(ValueError):
                ReviewQueue(root, 501)
            calls = []

            def classify(copies, _root, _tmp, _stage, _auto):
                self.assertEqual([b.name for b in copies], ["20261122_000620.bmp"])
                for copy in copies:
                    Path(str(copy) + ".data").write_text(annotation)

            def snapshot(bmp, *, source_data, **kwargs):
                (backup / (bmp.name + ".data")).write_bytes(source_data.read_bytes())

            def launch(_base, first):
                items = catchup.load()["items"]
                self.assertEqual(first.name, min(items))
                self.assertEqual(set(items), {p.name for p in first.parent.glob("*.bmp")})
                calls.append(len(items))
                if len(calls) == 1:
                    self.assertEqual({v["source"] for v in items.values()}, set(sources[:-1]))
                    # Close after saving two grades, including one beyond item 500.
                    for key, meta in items.items():
                        if meta["source"] in (sources[1], sources[601]):
                            grade(Path(str(first.parent / key) + ".data"))
                    snapshot_path = os.environ.get("TEST_QT_STAGE")
                    if snapshot_path:
                        import shutil
                        shutil.copytree(first.parent, snapshot_path)
                else:
                    self.assertEqual(calls, [625, 623])
                    for key in items:
                        grade(Path(str(first.parent / key) + ".data"))
                return 0

            pipeline = SimpleNamespace(classify=classify, care=SimpleNamespace(machine_snapshot=snapshot))
            try:
                with patch.object(fast_review_entrypoint, "start", side_effect=launch):
                    daily.run_queue(state, pipeline, {})
                    self.assertEqual(len(catchup.load()["items"]), 623)
                    for i in (1, 601):
                        self.assertEqual(human_grade(Path(str(root / sources[i]) + ".data")), 5)
                    self.assertIsNone(human_grade(Path(str(root / sources[600]) + ".data")))
                    daily.run_queue(state, pipeline, {})
                    self.assertFalse(daily.run_queue(state, pipeline, {}))
                self.assertEqual(calls, [625, 623])
                self.assertFalse(catchup.load()["items"])
                self.assertEqual(state.db.execute("SELECT COUNT(*) FROM review").fetchone()[0], 0)
            finally:
                state.db.close()


if __name__ == "__main__":
    unittest.main()
