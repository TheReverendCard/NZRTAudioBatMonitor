"""Exercise the installed AviaNZ Qt file list and Fast Review BMP navigation."""
from pathlib import Path
import sys

folder, gui_source, tool = (Path(arg).resolve() for arg in sys.argv[1:])
sys.path[:0] = [str(gui_source), str(tool)]
from PyQt5.QtWidgets import QApplication, QLabel
from PyQt5.QtGui import QColor
from SupportClasses_GUI import LightedFileList
from fast_review_entrypoint import install_bmp_only_navigation

app = QApplication([])


class Navigation:
    batmode = True
    openNextFile = batDailyMoveRight = batDailyMoveLeft = batDailyGrade = lambda self: None

    def batDailyEditingText(self):
        return False

    def listLoadFile(self, item):
        self.filename = str(folder / item.text())


install_bmp_only_navigation(Navigation)
gui = Navigation()
gui.listFiles = LightedFileList(QColor("red"), QColor("yellow"), QColor("green"))
gui.statusLeft = QLabel()
first = min(f.name for f in folder.glob("*.bmp"))
gui.filename = str(folder / first)
gui.listFiles.fill(str(folder), first)
visited = [first]
while True:
    previous = gui.filename
    gui.openNextFile()
    if gui.filename == previous:
        break
    visited.append(Path(gui.filename).name)
assert len(visited) == 625 and len(set(visited)) == 625
assert set(visited) == {p.name for p in folder.glob("*.bmp")}
gui.batDailyMoveLeft()
assert Path(gui.filename).name == visited[-2]
print(f"Qt reviewed list: {len(visited)} BMPs reachable from the initial file. "
      "Crossed positions 150 and 500 and reached the final BMP.", flush=True)
