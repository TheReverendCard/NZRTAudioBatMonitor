"""Install full-session daily review and the verified RT intake update."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


@contextmanager
def idle_daily(root):
    lock = root / "Daily_Run_Reports" / "Daily_Integration" / "review_first.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    with lock.open("a+b") as stream:
        if not stream.tell():
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError("Run Daily is active. Apply the update after it finishes.") from exc
        if any(p.is_file() for p in (root / ".bat_daily_tool.lock", root / "BatDailyTool" / ".bat_daily_tool.lock")):
            raise RuntimeError("Bat Daily has an active lock. Wait for its run to finish.")
        yield


def replace(path, data):
    fd, name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def install(root):
    here = Path(__file__).resolve().parent
    tool = root / "BatDailyTool"
    manifest = json.loads((here / "update.json").read_text(encoding="utf-8"))
    if not (tool / "review_first_daily.py").is_file():
        raise RuntimeError("BatDailyTool was not found under " + str(root))
    with idle_daily(root):
        pending = []
        for name, hashes in manifest.items():
            dest = tool / name
            data = (here / "program" / name).read_bytes()
            if sha(data) != hashes["after"]:
                raise ValueError("Update payload failed its hash check: " + name)
            compile(data, str(dest), "exec")
            original = dest.read_bytes() if dest.exists() else None
            if original == data:
                continue
            accepted = [hashes["before"], *hashes.get("also_before", [])]
            if (sha(original) if original is not None else None) not in accepted:
                raise RuntimeError("Installed file differs from the inspected version: " + name)
            pending.append((dest, data, original))
        if not pending:
            print("Full-session daily review and the RT import update are already installed.")
            return
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup = root / "Tool_Backups" / ("rt_batch_" + stamp)
        backup.mkdir(parents=True)
        for dest, _, original in pending:
            if original is not None:
                (backup / dest.name).write_bytes(original)
        changed = []
        try:
            for dest, data, original in pending:
                replace(dest, data)
                changed.append((dest, original))
        except BaseException:
            for dest, original in reversed(changed):
                if original is None:
                    dest.unlink()
                else:
                    replace(dest, original)
            raise
        print("Installed. Use the usual Run Daily shortcut. Original program files:", backup)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.home() / "Documents" / "Bat")
    args = parser.parse_args()
    install(args.root.resolve())
