# Bat Daily full-session review

Extract this ZIP, finish any active daily run, then double-click Install_Full_Daily_Review.bat.  Continue using your usual Run Daily shortcut.  The installer includes the RT importer and daily log packing update.  It accepts the inspected installation and the previously delivered RT update.  It saves the original program files under Documents\Bat\Tool_Backups and prints the backup path.

Run Daily opens one FastAviaNZ window containing every eligible recording in the prepared daily review list, including outstanding recordings from earlier sessions.  Previously graded recordings are reconciled before staging.  You can grade the entire set or close partway through.  The console reports grades reconciled and recordings remaining.  Closing with unfinished recordings leaves them for the next run.  Review All Unreviewed continues to stage 150 at a time by default.

On the first run of a newly initialised daily database, intake and indexing now finish before the review window opens.  This allows newly discovered eligible recordings to join that same session.  Existing hard-link checks, independently staged annotations, original-file conflict checks and machine baselines continue to protect the review workflow.

The checks folder contains the simulated daily review and Qt navigation tests.  The test staged 625 eligible BMPs in one window, saved two grades, resumed all 623 remaining BMPs, then confirmed that a completed queue skipped the next launch.  The installed AviaNZ Qt file list was exercised offscreen through all 625 filenames.  No field recordings were graded during verification.

Project notes and source changes are in https://github.com/TheReverendCard/NZRTAudioBatMonitor/pull/54.
