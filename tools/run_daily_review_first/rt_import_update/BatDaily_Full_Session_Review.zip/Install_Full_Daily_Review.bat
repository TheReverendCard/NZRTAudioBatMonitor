@echo off
setlocal
set "PY=%USERPROFILE%\Documents\Bat\BatDailyTool\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo BatDailyTool Python was not found under Documents\Bat.
  pause
  exit /b 1
)
"%PY%" -B "%~dp0install_update.py"
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
