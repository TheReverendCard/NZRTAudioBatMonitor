#pragma once
#include <cstdlib>
#define MALLOC_CAP_SPIRAM 1
#define MALLOC_CAP_8BIT 2
inline void* heap_caps_malloc(size_t n,int){return malloc(n);}

#define MALLOC_CAP_INTERNAL 4
