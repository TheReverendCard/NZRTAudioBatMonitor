#pragma once
struct WiFiClient {};
