#pragma once
#include <stdint.h>
#include <stddef.h>
#include "WildlifeScoring.h"
// Experimental, unclassified 18-45 kHz activity, NOT bat identification.
// Expects 3.072 MHz STD/MSB raw PDM little-endian stereo16 word chronology.
namespace WildlifeDetector {
void guardPressure(bool pressure);
const char* passName(unsigned);
bool preparePass(unsigned);
bool requestPass(unsigned);
unsigned passCurrent();
bool passApplied(unsigned);
void coverage(char*,size_t);
void passStatus(char*,size_t);
struct Event {
  unsigned passConfig;uint8_t triggerMask;bool fallback;bool shadowMatched;bool shadowIncomplete;
  uint32_t seq,start_ms,end_ms,run,start_uptime_ms,end_uptime_ms;
  float peak_ratio;
  WildlifeScoring::Features features;
  // 0=normal, 1=input gap, 2=run stopped, 3=10-second event limit.
  uint8_t ended_reason;
  const char* clipRequest;
  uint32_t clipOwnerSeq;
  bool bench;
};
struct Snapshot {
  uint32_t windows,candidates;
  float band_rms,noise_rms,peak_ratio;
  uint32_t bat_like,uncertain,event_queue_lost,input_gaps;
};
void reset(uint32_t run=0,uint32_t originUptimeMs=0);
void onInputGap(uint32_t missingBlocks);
void consume(const uint8_t* data,size_t bytes,uint32_t captureEndUptimeMs=0);
#ifdef NZRT_HOST_TEST
void setCostForTest(uint32_t);
void spectrumForTest(const float*,float*);
void consumePcmForTest(const float* pcm,size_t samples);
#endif
bool pop(Event& event);
void snapshot(Snapshot& out);
}
